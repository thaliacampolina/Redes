#ifndef ENCODE_H
#define ENCODE_H
#include <iostream>
#include <string.h>

using namespace std;


string codifica(string nome);


#endif
